@extends('layouts.app')

@section('content')
    <div id="content" class="content">
        <script>
            createList();
        </script>
    </div>
@endsection
